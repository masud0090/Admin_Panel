$(document).ready(function() {
    $('#example').DataTable();
});